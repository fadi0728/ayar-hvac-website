import React from "react";
import { motion } from "framer-motion";
import {
  Phone,
  Mail,
  MapPin,
  Flame,
  Snowflake,
  ShieldCheck,
  Clock,
  Wrench,
  Star,
  CheckCircle,
  ThermometerSun,
  Wind,
  CalendarCheck,
} from "lucide-react";

const services = [
  {
    icon: <Flame className="h-7 w-7" />,
    title: "Heating Repair & Installation",
    text: "Furnace repair, replacement, tune-ups, and seasonal maintenance for dependable heat when Michigan gets cold.",
  },
  {
    icon: <Snowflake className="h-7 w-7" />,
    title: "Air Conditioning Services",
    text: "AC repair, installation, system checks, and cooling solutions to keep your home comfortable all summer.",
  },
  {
    icon: <Wrench className="h-7 w-7" />,
    title: "Maintenance & Troubleshooting",
    text: "Honest diagnostics, preventative maintenance, and practical solutions before small issues become big repairs.",
  },
];

const serviceAreas = [
  "Macomb County",
  "Oakland County",
  "Washington Twp",
  "Rochester Hills",
  "Shelby Twp",
  "Sterling Heights",
  "Troy",
  "Utica",
];

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-zinc-950/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-zinc-950 shadow-lg">
              <span className="text-xl font-black tracking-tight">A</span>
            </div>
            <div>
              <p className="text-lg font-black tracking-wide">AYAR</p>
              <p className="-mt-1 text-xs font-semibold uppercase tracking-[0.28em] text-zinc-400">
                Heating & Cooling
              </p>
            </div>
          </div>

          <nav className="hidden items-center gap-8 text-sm font-medium text-zinc-300 md:flex">
            <a href="#services" className="hover:text-white">Services</a>
            <a href="#about" className="hover:text-white">Why Us</a>
            <a href="#areas" className="hover:text-white">Service Areas</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </nav>

          <a
            href="tel:5869218699"
            className="rounded-full bg-white px-4 py-2 text-sm font-bold text-zinc-950 shadow-lg transition hover:bg-zinc-200"
          >
            Call Now
          </a>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(249,115,22,0.28),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(37,99,235,0.32),transparent_40%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:py-28">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm text-zinc-200">
              <ShieldCheck className="h-4 w-4" /> Licensed HVAC service you can trust
            </div>
            <h1 className="text-5xl font-black leading-tight tracking-tight md:text-7xl">
              Reliable heating & cooling for your home.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-zinc-300">
              Ayar Heating & Cooling provides professional HVAC repair, installation, and maintenance with honest service, clean work, and fast response times.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href="tel:5869218699"
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-orange-500 px-6 py-4 font-black text-white shadow-xl shadow-orange-500/20 transition hover:bg-orange-400"
              >
                <Phone className="h-5 w-5" /> Call 586-921-8699
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-6 py-4 font-bold text-white transition hover:bg-white/15"
              >
                Request Service
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 shadow-2xl backdrop-blur">
              <div className="rounded-[1.5rem] bg-zinc-900 p-7">
                <div className="mb-8 flex items-center justify-between">
                  <div>
                    <p className="text-sm uppercase tracking-[0.25em] text-zinc-400">
                      Comfort System
                    </p>
                    <p className="mt-1 text-2xl font-black">Home HVAC Care</p>
                  </div>
                  <div className="flex gap-2">
                    <div className="rounded-2xl bg-orange-500/15 p-3 text-orange-400">
                      <Flame />
                    </div>
                    <div className="rounded-2xl bg-blue-500/15 p-3 text-blue-400">
                      <Snowflake />
                    </div>
                  </div>
                </div>
                <div className="grid gap-4">
                  {[
                    "Fast diagnostics",
                    "Clean installations",
                    "Seasonal tune-ups",
                    "Honest recommendations",
                  ].map((item) => (
                    <div key={item} className="flex items-center gap-3 rounded-2xl bg-white/5 p-4">
                      <CheckCircle className="h-5 w-5 text-green-400" />
                      <span className="font-semibold text-zinc-100">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-4 px-5 py-8 md:grid-cols-3">
        <Feature icon={<Clock />} title="Fast Response" text="Prompt help when your heat or AC stops working." color="text-orange-400" />
        <Feature icon={<ShieldCheck />} title="Licensed & Professional" text="Quality HVAC work with attention to detail." color="text-blue-400" />
        <Feature icon={<Star />} title="Honest Service" text="Clear explanations and straightforward recommendations." color="text-yellow-300" />
      </section>

      <section id="services" className="mx-auto max-w-7xl px-5 py-20">
        <div className="max-w-2xl">
          <p className="font-bold uppercase tracking-[0.25em] text-orange-400">Our Services</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">
            Comfort solutions for every season.
          </h2>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {services.map((service) => (
            <div
              key={service.title}
              className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-7 transition hover:-translate-y-1 hover:bg-white/[0.09]"
            >
              <div className="mb-6 inline-flex rounded-2xl bg-white/10 p-4 text-white">
                {service.icon}
              </div>
              <h3 className="text-2xl font-black">{service.title}</h3>
              <p className="mt-4 leading-7 text-zinc-400">{service.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="about" className="bg-white text-zinc-950">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 py-20 md:grid-cols-2">
          <div>
            <p className="font-bold uppercase tracking-[0.25em] text-blue-600">Why Choose Ayar</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">
              A clean, professional HVAC experience.
            </h2>
          </div>
          <div className="grid gap-4">
            {[
              [ThermometerSun, "We help keep your home comfortable year-round."],
              [Wind, "We service heating, cooling, airflow, and comfort concerns."],
              [CalendarCheck, "We offer maintenance options to protect your system."],
            ].map(([Icon, text]) => (
              <div key={text} className="flex gap-4 rounded-3xl bg-zinc-100 p-5">
                <Icon className="mt-1 h-6 w-6 text-zinc-900" />
                <p className="text-lg font-semibold leading-7">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="areas" className="mx-auto max-w-7xl px-5 py-20">
        <p className="font-bold uppercase tracking-[0.25em] text-blue-400">Service Areas</p>
        <h2 className="mt-3 text-4xl font-black tracking-tight">
          Proudly serving Metro Detroit communities.
        </h2>
        <div className="mt-8 flex flex-wrap gap-3">
          {serviceAreas.map((area) => (
            <span
              key={area}
              className="rounded-full border border-white/10 bg-white/[0.06] px-5 py-3 font-semibold text-zinc-200"
            >
              {area}
            </span>
          ))}
        </div>
      </section>

      <section id="contact" className="mx-auto max-w-7xl px-5 pb-20">
        <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-zinc-900 to-zinc-800">
          <div className="grid gap-8 p-8 md:grid-cols-2 md:p-12">
            <div>
              <p className="font-bold uppercase tracking-[0.25em] text-orange-400">Request Service</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight">Need HVAC help?</h2>
              <p className="mt-4 max-w-lg leading-7 text-zinc-300">
                Call today or send a message to schedule service, ask a question, or request an estimate.
              </p>
              <div className="mt-8 space-y-4 text-zinc-200">
                <a href="tel:5869218699" className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-orange-400" /> 586-921-8699
                </a>
                <a href="mailto:info@ayarhvac.com" className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-blue-400" /> info@ayarhvac.com
                </a>
                <p className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-zinc-400" /> Serving Macomb & Oakland County
                </p>
              </div>
            </div>

            <form className="rounded-[1.5rem] bg-white p-5 text-zinc-950 shadow-2xl">
              <div className="grid gap-4">
                <input className="rounded-2xl border border-zinc-200 px-4 py-4 outline-none focus:border-zinc-900" placeholder="Your name" />
                <input className="rounded-2xl border border-zinc-200 px-4 py-4 outline-none focus:border-zinc-900" placeholder="Phone number" />
                <input className="rounded-2xl border border-zinc-200 px-4 py-4 outline-none focus:border-zinc-900" placeholder="Email address" />
                <textarea className="min-h-32 rounded-2xl border border-zinc-200 px-4 py-4 outline-none focus:border-zinc-900" placeholder="How can we help?" />
                <button type="button" className="rounded-2xl bg-zinc-950 px-6 py-4 font-black text-white transition hover:bg-zinc-800">
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 px-5 py-8 text-center text-sm text-zinc-500">
        © 2026 Ayar Heating & Cooling. All rights reserved. | ayarhvac.com
      </footer>
    </div>
  );
}

function Feature({ icon, title, text, color }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-6">
      <div className={`mb-4 h-7 w-7 ${color}`}>{icon}</div>
      <h3 className="text-xl font-black">{title}</h3>
      <p className="mt-2 text-zinc-400">{text}</p>
    </div>
  );
}
